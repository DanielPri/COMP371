Hi,

The xxx.bmp is the result of Ray traycing the same_name.txt.
Before you try your height maps of Assignment 2, you can use the sceneOBJ.txt to load the cube.obj and render renderOBJ.bmp  for debugging purposes.

Since you are using your own .obj files, please pay attention to the positions and directions of your cameras, vertices and lights.

Best of luck.
